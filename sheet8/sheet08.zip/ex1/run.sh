g++ -o ex1 ex1.cpp
./ex1
python3 plot.py